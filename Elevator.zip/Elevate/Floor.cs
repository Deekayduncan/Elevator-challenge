﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elevate
{
    public class Floor
    {
        public int FloorID { get; set; }
        public int DropOffNo { get; set; }
    }
}
